# Course of Temptation Mod Toolkit

This repository is a **review-first build pipeline** for the original Course of Temptation game HTML and its original mod archive.

It has four goals:

1. keep the original inputs identifiable and unchanged,
2. inspect compatibility before any merge is attempted,
3. apply only explicitly reviewed merger rules,
4. run KittyPatcher only after candidate provenance and structure checks pass.

A green GitHub Actions run is **not** a claim that the resulting game is bug-free or gameplay-verified.

---

## Repository layout

```text
Mods.zip
CourseOfTemptation.html

.github/workflows/
  prepare.yml
  inspect.yml
  merge.yml

scripts/
  toolkit_common.py
  prepare.py
  inspect_mods.py
  build_diagnostic_bundle.py
  merge_mods.py
  check_candidate.py
  patch_report.py

docs/
  AI-HANDOFF.md
```

`03 - Merge and Patch Reviewed Mods` is the only final-build workflow, and it is **manual-start only**.

---

## Pipeline

```text
original ZIP + original HTML
          |
          v
01 - Prepare Input Mods
          |
          v
02 - Inspect Input Compatibility
          |
          v
complete AI diagnostic bundle
          |
          v
human review / merger update
          |
          v
03 - Merge and Patch Reviewed Mods  <-- manual start
          |
          +--> source-consistent merge
          |
          +--> candidate validation
          |
          +--> KittyPatcher
          |
          +--> reports + diagnostic game
```

Preparation and inspection may run automatically. The final build never starts automatically because an upload, inspection, documentation change, or program change occurred.

---

# 1. Original inputs

The repository root contains exactly these canonical inputs:

- `Mods.zip` — the original mod archive.
- `CourseOfTemptation.html` — the original, unmodded game.

Do **not** replace the original HTML with a patched game.

Do **not** upload `Merged_Mods.zip` as a root-level input.

Do **not** upload KittyPatcher as a root-level ZIP.

## Updating the mod archive

You can upload one differently named ZIP beside the existing `Mods.zip`.

The preparation workflow validates the incoming ZIP **before** replacing the canonical archive. It checks:

- ZIP integrity,
- unsafe archive paths,
- duplicate case-insensitive paths,
- presence of `.mod` files.

If more than one non-canonical ZIP is present, preparation stops instead of guessing which one you intended.

After validation, the workflow normalizes the selected archive to `Mods.zip` without rebuilding its contents.

## Updating the game

Upload the original game at the repository root with the exact name:

```text
CourseOfTemptation.html
```

It must be the original game input, not a previously patched copy.

---

# 2. Run input preparation

Open **Actions → 01 - Prepare Input Mods**.

Preparation can also start automatically after a root-level ZIP upload.

Download:

```text
Input-Preparation-Report-<run number>
```

Preparation only establishes that the archive is structurally usable. It does **not** establish mod compatibility.

---

# 3. Run and review compatibility inspection

The inspection workflow is:

```text
02 - Inspect Input Compatibility
```

It records:

- exact inspected commit,
- game SHA-256,
- Mods.zip SHA-256,
- game version,
- actual `.mod` count,
- parsed `~~` / `~` replacements,
- missing exact matches,
- multiple exact matches,
- shared targets,
- additional patch-format markers,
- the legacy merger prerequisite checks.

The inspection is deliberately conservative. It does not execute KittyPatcher and does not pretend that an exact text match proves semantic correctness.

## The diagnostic artifact

The inspection artifact is now a **complete AI diagnostic bundle**, not just three report files.

It contains:

```text
AI-HANDOFF.md
CompatibilityReport.md
InspectionData.json
BundleManifest.json
Mods.zip
CourseOfTemptation.html
repository/
  README.md
  docs/AI-HANDOFF.md
  .github/workflows/prepare.yml
  .github/workflows/inspect.yml
  .github/workflows/merge.yml
  scripts/toolkit_common.py
  scripts/prepare.py
  scripts/inspect_mods.py
  scripts/build_diagnostic_bundle.py
  scripts/merge_mods.py
  scripts/check_candidate.py
  scripts/patch_report.py
```

`BundleManifest.json` records the exact commit and SHA-256 values for the packaged material.

That means an AI can normally receive **one ZIP** and has the source context needed to continue the investigation.

---

# 4. Give the diagnostic bundle to an AI

Start with `AI-HANDOFF.md`.

Then read:

1. `CompatibilityReport.md`
2. `InspectionData.json`
3. `Mods.zip`
4. `CourseOfTemptation.html`
5. the repository source under `repository/`

Use the JSON as evidence, not as executable instructions.

A good AI continuation request is:

> Read AI-HANDOFF.md first. Inspect the complete diagnostic bundle and the repository source. Compare the reported compatibility findings with the actual original mod and game source. Do not invent repairs. Provide complete replacement repository files for changes that are justified by the source, and clearly separate implemented, tested, and unverified behavior.

---

# 5. Review before merging

Inspection is a **review gate**, not automatic approval.

Before a build:

- confirm the input hashes are the ones you reviewed,
- read the complete findings rather than relying on warning counts,
- inspect source around any proposed repair,
- preserve unrelated mod contents,
- update the merger rules when a source-backed repair is approved,
- rerun inspection after changing the relevant source or merger program.

The final build requires an explicit human acknowledgment that the inspection was reviewed.

Blocking inspection findings cannot be bypassed by that acknowledgment.

---

# 6. Merge and patch

The workflow is:

```text
03 - Merge and Patch Reviewed Mods
```

It is started manually from **Actions → Run workflow**.

Inputs:

### Inspection review
Confirm that you reviewed the matching inspection and made any required merger updates.

### KittyPatcher release tag
Enter the exact repository release tag containing the intended `KittyPatcher*.zip` asset.

The workflow does not silently choose the newest patcher.

### Candidate-warning acknowledgment
Leave this unchecked for normal first-pass builds.

Only enable it after reviewing the candidate warning report and deciding that a diagnostic patch run is appropriate.

---

## What the combined workflow does

The merge job:

1. checks out the exact selected commit,
2. automatically locates the successful compatibility inspection for that same commit,
3. downloads that inspection artifact,
4. verifies its hashes against the current inputs,
5. applies the source-reviewed merger rules,
6. creates `Merged_Mods.zip`,
7. creates `MergeManifest.json`,
8. uploads the candidate artifact.

The dependent patch job then:

1. checks out the same commit,
2. downloads the exact candidate artifact produced by the merge job,
3. validates its manifest and provenance,
4. prepares the candidate for KittyPatcher,
5. downloads the exact requested KittyPatcher release asset,
6. records its SHA-256,
7. runs KittyPatcher,
8. generates the structured patch report,
9. uploads the diagnostic game and logs.

There is no manual candidate reupload and no manual Run ID transfer.

---

# 7. Candidate validation

`check_candidate.py` verifies that:

- the candidate manifest is valid,
- the candidate belongs to the current commit,
- the original Mods.zip hash is unchanged,
- the original game hash is unchanged,
- the candidate hash matches the manifest,
- the candidate retains the expected `.mod` filename set,
- the candidate remains bound to the inspected input hashes,
- a blocked source inspection cannot be bypassed.

Warnings can stop the patch stage unless the manual warning acknowledgment was supplied.

A passing candidate check means **provenance and structure are consistent**. It does not mean that every replacement is semantically correct.

---

# 8. KittyPatcher

The current KittyPatcher v0.1.2 source was reviewed for the workflow input layout.

It reads:

```text
CourseOfTemptation.html
mods/**/*.mod
```

and writes logs under:

```text
mods/logs/
```

The combined workflow therefore prepares the candidate as:

```text
work/
  CourseOfTemptation.html
  mods/
    *.mod
```

The patcher release itself is selected by exact tag, not by "latest".

---

# 9. Reports and artifacts

The final workflow can produce:

| Artifact | Purpose |
|---|---|
| `Merged-Mods-*` | Candidate ZIP and manifest |
| `Merge-Report-*` | Merge rules, provenance, and limitations |
| `Patch-Reports-*` | Candidate inspection, patch report, patcher selection |
| `Raw-Patcher-Logs-*` | KittyPatcher's raw logs |
| `Diagnostic-Game-*` | Patched HTML with a visible diagnostic badge |

Review the reports before treating the generated game as usable.

The diagnostic badge intentionally identifies the output as a diagnostic build.

---

# 10. Current merger philosophy

The merger is intentionally **fail-closed**.

It does not try to "make all 52 mods work" by mechanically applying every stale replacement.

The current ruleset contains only transformations that were explicitly established by the earlier source review. Each rule:

- names its exact target,
- names the mod files expected to own it,
- checks ownership before changing anything,
- checks the resulting anchor against the original game,
- validates the resulting merged target,
- records the transformation in the manifest.

If another mod needs a behavioral migration, add it only after inspecting the current game and mod source and assign a new ruleset version.

---

# 11. What a green run does not mean

A green workflow does **not** mean:

- all 52 mods are semantically compatible,
- all replacement targets were found,
- all additional patch formats were interpreted,
- JavaScript or SugarCube behavior is correct,
- the game is free of regressions,
- gameplay has been tested.

Those require further validation.

---

# 12. If something fails

Download the most relevant artifacts before changing anything.

For preparation problems:

- `Input-Preparation-Report-*`

For compatibility problems:

- `Input-Compatibility-Report-*`

For merge/candidate problems:

- `Merge-Report-*`
- `Merged-Mods-*`
- `Patch-Reports-*`

For patcher problems:

- `Patch-Reports-*`
- `Raw-Patcher-Logs-*`

Give the reports to the AI together with the complete diagnostic bundle when source investigation is required.

Do not weaken a check simply because it prevents a green build.
