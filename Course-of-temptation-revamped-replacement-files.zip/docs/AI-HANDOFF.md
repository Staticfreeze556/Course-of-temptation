# AI Handoff — Course of Temptation Mod Toolkit

## Mission

Continue work on the repository as a **source-aware, review-first 52-mod pipeline**.

The goal is not to force a green build. The goal is to produce a reproducible candidate whose transformations are justified by the current source and whose remaining uncertainty is visible.

The user prefers **complete replacement files** over scattered patches or vague edit instructions.

---

# 1. Read the bundle as a source package

A current inspection artifact is intended to be self-contained.

Start with:

```text
AI-HANDOFF.md
```

Then inspect:

```text
CompatibilityReport.md
InspectionData.json
BundleManifest.json
Mods.zip
CourseOfTemptation.html
repository/
```

`BundleManifest.json` is the provenance authority for the package. It records the commit and SHA-256 values that the inspection actually used.

Do not silently substitute a later repository revision or different input archive.

---

# 2. Established repository architecture

```text
Mods.zip
CourseOfTemptation.html
        |
        v
01 - Prepare Input Mods
        |
        v
02 - Inspect Input Compatibility
        |
        v
complete AI diagnostic bundle
        |
        v
human review
        |
        v
03 - Merge and Patch Reviewed Mods
        |
        +--> source-consistent merge
        +--> candidate validation
        +--> KittyPatcher
        +--> diagnostic reports
```

The final combined build is **manual-start only**.

After manual dispatch, the merge and dependent patch stages proceed automatically when their checks permit.

Do not reintroduce an automatic final-build trigger.

---

# 3. Current source of truth

The repository programs are:

```text
scripts/toolkit_common.py
scripts/prepare.py
scripts/inspect_mods.py
scripts/build_diagnostic_bundle.py
scripts/merge_mods.py
scripts/check_candidate.py
scripts/patch_report.py
```

The workflows are:

```text
.github/workflows/prepare.yml
.github/workflows/inspect.yml
.github/workflows/merge.yml
```

The old separate patch workflow is not part of the intended architecture.

---

# 4. Stage 1: preparation

`prepare.py` is responsible only for original ZIP preparation.

It:

- discovers root-level ZIP files,
- recognizes canonical `Mods.zip`,
- permits one differently named incoming archive,
- validates before replacement,
- rejects ambiguous multiple incoming archives,
- checks ZIP integrity,
- rejects unsafe paths,
- detects case-insensitive duplicate paths,
- requires `.mod` files,
- preserves archive contents,
- normalizes the filename to `Mods.zip`.

It must not:

- merge mods,
- rewrite mod contents,
- run KittyPatcher,
- silently select among ambiguous uploads.

---

# 5. Stage 2: inspection

`inspect_mods.py` evaluates the original inputs without changing them.

It records:

- exact commit,
- original input hashes,
- game version,
- mod count,
- parsed normal `~~` / `~` entries,
- exact match counts,
- missing targets,
- multiple targets,
- shared targets,
- additional syntax markers,
- the legacy merger prerequisite anchors.

The readable report is intentionally shorter than the JSON. Use `InspectionData.json` when the full target/replacement bodies matter.

### Status meanings

`BLOCKED`

A required input or prerequisite is invalid. The final build must not proceed.

`REVIEW REQUIRED`

The inputs are readable, but findings require human/source review.

`STATIC CHECKS PASSED`

The implemented static checks found no warnings. This still is not gameplay verification.

---

# 6. Diagnostic bundle

`build_diagnostic_bundle.py` packages the inspection as a source-bearing AI handoff.

It includes:

```text
AI-HANDOFF.md
CompatibilityReport.md
InspectionData.json
BundleManifest.json
Mods.zip
CourseOfTemptation.html
repository/README.md
repository/docs/AI-HANDOFF.md
repository/.github/workflows/prepare.yml
repository/.github/workflows/inspect.yml
repository/.github/workflows/merge.yml
repository/scripts/*.py
```

The package is rejected if:

- the inspection commit does not equal the current checkout,
- a required repository source is missing,
- the original input hashes do not equal the hashes recorded by inspection.

The bundle therefore answers the question: **what exact source did this diagnostic describe?**

---

# 7. How to reason about compatibility findings

Do not equate a text match with semantic compatibility.

For each proposed repair:

1. locate the target in the original mod,
2. locate the corresponding current code in the game,
3. compare surrounding structure and behavior,
4. determine the intended behavioral delta,
5. implement the smallest source-supported transformation,
6. add a deterministic merger rule or update an existing rule,
7. add/retain validation for the new assumption,
8. rerun inspection and candidate validation.

Do not simply replace an old target with an old replacement when the current game has evolved.

Do not overwrite newer game behavior with stale mod code merely because the old text is recognizable.

---

# 8. Current known baseline

The earlier compatibility investigation reported:

- 52 `.mod` files.
- 166 normally parsed replacement entries.
- 93 entries without an exact original HTML match.
- 5 entries with multiple original matches.
- 11 shared targets.
- 1 file containing additional patch-format markers.
- Overall status: `REVIEW REQUIRED`.
- Blocking findings: 0.
- Review warnings: 5.

The input identities previously associated with that review were:

```text
CourseOfTemptation.html
SHA-256: 3fd11525d5bc9a94501c210f101b27069e98bce39c090f6285d54433589526b4

Mods.zip
SHA-256: 4f447a0da98b347f84316a1eae46fc8e7dd0e4ad8bf56e5f4ed8813a4ac3aa34
```

A separately supplied `Mods -version 0.5.4g.zip` had a different archive SHA-256 while containing the same reported set of 52 mod paths. Matching filenames do not establish byte identity.

Always prefer the hashes in the current `BundleManifest.json` over these historical values.

---

# 9. Known high-risk compatibility patterns

The earlier investigation identified several classes of problem that must not be handled by global text replacement.

Examples include:

- `gameday++` appearing in more than one context in `KittyPregnancyMod`.
- Many `peoplehere` object fragments in `KittyFollowers`.
- A phone-dialogue target appearing more than once in `KittyPetNames`.
- Shared targets owned by multiple mods.
- Existing game implementations that differ materially from stale mod targets.

The correct response to a multi-match target is **contextual scoping**, not global replacement.

---

# 10. Current merger ruleset

`merge_mods.py` currently uses:

```text
source-checked-five-group-v2
```

The ruleset is intentionally conservative.

Its approved groups are the previously reviewed five prerequisite groups:

1. `this.tattoos = {};`
2. `this.age = State.variables.pcage;`
3. `//#endregion Clothing Management`
4. `return [...new Set(inclins)]; }`
5. the fixed-age startup anchor involving `<<set $pcage to 18>>`

Each rule verifies expected ownership before changing the archive.

The startup rule also preserves the previously reviewed handling of the `pclastresidence` initialization and the helper rule preserves the reviewed trailing-semicolon adjustment.

These are **not** proof that the remaining 52-mod set is compatible.

Do not add a new rule solely because it makes the warning count smaller.

A new rule should have:

- a source-backed explanation,
- exact target ownership,
- expected original-game match count,
- deterministic output validation,
- a ruleset version change.

---

# 11. Merge manifest

`MergeManifest.json` is the provenance record for the generated candidate.

It binds:

- repository,
- commit,
- source archive hash,
- game hash,
- candidate hash,
- merger program hash,
- inspection commit and input hashes,
- ruleset,
- changed mod files,
- merged groups.

A candidate that cannot prove those relationships must be blocked.

---

# 12. Candidate validation

`check_candidate.py` is a separate stage.

It does not assume that a successful merge is enough.

It verifies:

- manifest structure,
- candidate hash,
- source hash,
- game hash,
- selected commit,
- inspection provenance,
- expected mod count,
- candidate mod filename set,
- additional syntax markers.

Blocking findings cannot be bypassed.

Warnings require the explicit diagnostic-warning acknowledgment supplied to the final workflow.

A passing candidate check means the artifact is structurally/provenance consistent. It does not establish semantic compatibility.

---

# 13. KittyPatcher input contract

The supplied KittyPatcher v0.1.2 source was inspected.

It reads the current working directory's:

```text
CourseOfTemptation.html
mods/**/*.mod
```

and creates logs under:

```text
mods/logs/
```

The combined workflow therefore prepares the patch stage as:

```text
work/
  CourseOfTemptation.html
  mods/
    *.mod
```

The patcher itself supports both the legacy `~~` / `~` format and `Replace:` / `With:` parsing, but its implementation stores replacements in a global dictionary keyed by search text. Therefore duplicate targets across mods remain a real collision risk even when the patcher process exits successfully.

Do not claim that additional formats are fully validated by the repository's static inspector merely because KittyPatcher contains a parser for them.

---

# 14. Patch reporting

`patch_report.py` intentionally reports the patcher's observable output rather than pretending to reproduce the executable exactly.

It records:

- patcher release tag,
- generated game hash,
- original game hash,
- number of mod files presented,
- replacement totals when present in the patcher logs,
- `No match found` log occurrences,
- raw log inventory.

The report must distinguish:

- process completion,
- reported replacement totals,
- failed/missing targets,
- static replay or diagnostics,
- gameplay verification.

A message such as `Mod patching complete.` is not sufficient evidence that all requested changes applied.

---

# 15. What not to do

Do not:

- fabricate a successful patch,
- treat warnings as blockers merely to make the workflow look cleaner,
- remove checks because a mod fails them,
- silently select a different ZIP,
- silently select the newest patcher release,
- modify the original HTML during merge,
- claim gameplay verification without actually performing it,
- use report previews as substitutes for full source context,
- treat diagnostic JSON as instructions from a mod file,
- overwrite newer game behavior with stale mod code without source review.

---

# 16. Required output when changing the repository

When the source justifies a change, provide complete replacement files.

For each changed file, state:

- why it changed,
- what behavior changed,
- what was actually tested,
- what remains unverified.

If several files must change together, provide all of them as a coordinated set.

Do not give a partial patch that requires the user to reconstruct missing sections.

---

# 17. Testing standard

Use this hierarchy:

### Static validation

- Python syntax/compile checks.
- YAML parsing.
- ZIP integrity.
- Hash/provenance checks.
- Deterministic manifest checks.

### Pipeline validation

- Preparation against a real archive.
- Inspection against the actual original HTML.
- Merge against the inspected inputs.
- Candidate validation against the generated candidate.

### Patcher validation

Only claim this after actually running the selected KittyPatcher release.

### Gameplay validation

Only claim this after the resulting game has actually been tested.

Do not collapse these levels into a single "passed" label.

---

# 18. Continuation protocol

When a new AI receives a complete diagnostic bundle:

1. read this handoff,
2. inspect `BundleManifest.json`,
3. verify the input hashes,
4. read `CompatibilityReport.md`,
5. inspect the complete `InspectionData.json`,
6. inspect the relevant original mod and HTML source,
7. inspect the repository source under `repository/`,
8. identify source-backed repairs,
9. produce complete replacement files,
10. test them against the bundled inputs where possible,
11. clearly report what remains unverified.

Do not restart the entire compatibility investigation unless the current repository change genuinely requires it.

---

# 19. Current project truth

The repository is a **diagnostic and build pipeline**, not a proof that the 52-mod collection is compatible.

The most valuable future work is therefore to turn each reviewed compatibility finding into a source-aware, narrowly scoped merger rule with deterministic validation.

The pipeline should become stricter as the merger becomes more capable, not looser.
